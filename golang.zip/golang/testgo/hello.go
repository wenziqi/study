package main

import "fmt"

func main(){

    fmt.Printf("hello world,My Name Is 温少奇\n")
}
