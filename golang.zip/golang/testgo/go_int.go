package main

import "fmt"

func main() {
	var i int = 10
	var j = 100
	k := 1000
	fmt.Println(i,j,k)
}