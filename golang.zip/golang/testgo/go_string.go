package main
import "fmt"

func main(){
	var s1 string = "hello world"
	var s2 string 
	s3 := "other string "
	s2="this is gostyle string"
	fmt.Println(s1)
	fmt.Println(s2)
	fmt.Println(s3)
}